'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

type Message = { role: 'user' | 'assistant'; text: string };

export default function ChatClient({ chatId }: { chatId: string }) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const router = useRouter();

  // Lies Streaming‑Antworten aus und füge sie der UI hinzu
  const readStream = async (
    reader: ReadableStreamDefaultReader<Uint8Array>,
  ) => {
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split('\n');
      buffer = parts.pop()!; // Rest zurückbehalten
      for (const part of parts) {
        if (!part.trim()) continue;
        try {
          const msg = JSON.parse(part) as Message;
          setMessages((prev) => {
            const last = prev[prev.length - 1];
            if (last?.role === msg.role) {
              return [
                ...prev.slice(0, -1),
                { role: last.role, text: last.text + msg.text },
              ];
            }
            return [...prev, msg];
          });
        } catch {
          // wenn kein JSON, einfach als Text anhängen
          setMessages((prev) => {
            const last = prev[prev.length - 1];
            if (last?.role === 'assistant') {
              return [
                ...prev.slice(0, -1),
                { role: 'assistant', text: last.text + part },
              ];
            }
            return [...prev, { role: 'assistant', text: part }];
          });
        }
      }
    }
  };

  // on mount: alle bisherigen Nachrichten streamen
  useEffect(() => {
    let canceled = false;
    (async () => {
      const res = await fetch(`/api/chat?chatId=${chatId}`);
      if (!res.ok || canceled || !res.body) return;
      await readStream(res.body.getReader());
    })();
    return () => {
      canceled = true;
    };
  }, [chatId]);

  // Senden einer neuen Nachricht
  const sendMessage = async () => {
    if (!input.trim()) return;
    setMessages((prev) => [...prev, { role: 'user', text: input }]);
    const payload = {
      id: chatId,
      message: {
        id: crypto.randomUUID(),
        parts: [{ type: 'text', text: input }],
      },
      selectedChatModel: 'chat-model-default',
      selectedVisibilityType: 'private',
    };
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert('Fehler beim Senden');
      return;
    }
    setInput('');
    await readStream(res.body!.getReader());
  };

  return (
    <div className="flex h-screen flex-col">
      <header className="border-b px-4 py-2">
        <button onClick={() => router.push('/chat')}>← zurück</button>
      </header>
      <main className="flex-1 overflow-auto p-4 space-y-4">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`max-w-xl ${
              m.role === 'user' ? 'ml-auto bg-blue-100' : 'mr-auto bg-gray-100'
            } rounded px-3 py-2`}
          >
            {m.text}
          </div>
        ))}
      </main>
      <footer className="border-t p-4">
        <div className="flex">
          <input
            className="flex-1 rounded border px-3 py-2"
            value={input}
            onChange={(e) => setInput(e.currentTarget.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          />
          <button
            onClick={sendMessage}
            className="ml-2 rounded bg-green-600 px-4 py-2 text-white hover:bg-green-700"
          >
            Senden
          </button>
        </div>
      </footer>
    </div>
  );
}

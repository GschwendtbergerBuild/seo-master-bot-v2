// app/chat/actions.ts
import { auth } from '@/app/(auth)/auth';
import { getChatsByUserId, saveChat } from '@/lib/db/queries';
import { v4 as uuid } from 'uuid';

export async function listChats() {
  const session = await auth();
  if (!session?.user?.id) throw new Error('Unauthorized');
  return getChatsByUserId({ userId: session.user.id });
}

export async function createChat() {
  const session = await auth();
  if (!session?.user?.id) throw new Error('Unauthorized');
  const id = uuid();
  await saveChat({
    id,
    userId: session.user.id,
    title: 'Neuer Chat',
    visibility: 'private',
  });
  return { id };
}

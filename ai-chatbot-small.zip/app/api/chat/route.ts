import { NextResponse } from 'next/server';
import { auth } from '@/app/(auth)/auth';
import { getChatsByUserId } from '@/lib/db/queries';

export async function GET(request: Request) {
  // Session prüfen
  const session = await auth();
  if (!session?.user?.id) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  // Chats für den eingeloggten Nutzer laden
  const chats = await getChatsByUserId({
    id: session.user.id,
    limit: 50,
    startingAfter: null,
    endingBefore: null,
  });

  return NextResponse.json(chats);
}

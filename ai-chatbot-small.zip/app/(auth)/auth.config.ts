// app/(auth)/auth.config.ts
import type { AuthConfig } from '@auth/core';
import { UpstashRedisAdapter } from '@auth/upstash-redis-adapter';
import redis from '@/lib/redis';

export const authConfig: AuthConfig = {
  providers: [], // ← hier müssen die Provider eingetragen werden
  adapter: UpstashRedisAdapter(redis),
  pages: {
    signIn: '/login',
    newUser: '/',
  },
  callbacks: {
    // jwt- und session-Callbacks definierst Du in auth.ts
  },
};

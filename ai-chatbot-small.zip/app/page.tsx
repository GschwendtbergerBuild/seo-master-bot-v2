// app/page.tsx
import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="flex h-screen items-center justify-center bg-gray-50">
      <div className="text-center">
        <h1 className="mb-8 text-4xl font-bold">Willkommen zum AI‑Chatbot</h1>
        <Link href="/chat">
          <button className="rounded bg-green-600 px-6 py-3 text-white hover:bg-green-700">
            Chat starten
          </button>
        </Link>
      </div>
    </main>
  );
}
